﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.App
{
    public class Checkout
    {
        public List<PricingRule> PricingRules { set; get; }
        public Checkout(List<PricingRule> pricingRules)
        {
            PricingRules = pricingRules;
        }
        Dictionary<string, int> shoppingCart = new Dictionary<string, int>();

        double total = 0;
        public void Scan(string item)
        {
            if (shoppingCart.ContainsKey(item))
            {
                shoppingCart[item]++;
            }
            else
            {
                shoppingCart.Add(item, 1);
            }
        }
        public double Total(List<Product> product)
        {
            int Countmbp = 0;
            foreach (var (j, rule, prod) in from j in shoppingCart
                                            let rule = PricingRules.FirstOrDefault(f => f.SKU == j.Key)
                                            let prod = product.FirstOrDefault(i => j.Key == i.SKU)
                                            where rule != null
                                            select (j, rule, prod))
            {
                if (j.Key == "mbp")
                {
                    Countmbp = j.Value;
                }
                total += rule.PaidCount(j.Value, Countmbp) * rule.PaidPrice(prod.Price, j.Value);
            }
            return total;
        }
    }
}
