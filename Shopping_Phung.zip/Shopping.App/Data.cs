﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.App
{
    public class Data
    {
        public static readonly List<Product> PRODUCTS = new List<Product>()
        {
            new Product("ipd", "Super iPad", 549.99),
            new Product("mbp", "MacBook Pro", 1399.99),
            new Product("atv", " Apple TV", 109.50),
            new Product("vga", "VGA adapter", 30.00)
        };

        public static readonly List<PricingRule> PRICERULES = new List<PricingRule>()
        {
            new PricingRule("ipd", "discount"),
            new PricingRule("mbp", "default"),
            new PricingRule("atv", "get1"),
            new PricingRule("vga", "addon")
        };
    }
}
