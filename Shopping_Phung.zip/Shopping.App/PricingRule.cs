﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.App
{
    public class PricingRule
    {
        public PricingRule(string sku, string promotion)
        {
            SKU = sku;
            Promotion = promotion;
        }
        public string Promotion { set; get; }
        public string SKU { set; get; }
        public int PaidCount(int buyCount, int dependentNumber)
        {
            int paidCount = buyCount;
            if (Promotion == "get1")
            {
                paidCount = buyCount - ((buyCount / 3) < 1 ? 0 : (buyCount / 3));
            }
            else if (Promotion == "addon")
            {
                if (buyCount > dependentNumber)
                    paidCount = buyCount - dependentNumber;
                else
                    paidCount = 0;
            }
            return paidCount;
        }

        public double PaidPrice(double buyPrice, int buyCount)
        {
            double paidPrice = buyPrice;
            if (Promotion == "discount")
            {
                if (buyCount > 4)
                {
                    paidPrice = 499.99;
                }
            }
            return paidPrice;
        }
    }
}
