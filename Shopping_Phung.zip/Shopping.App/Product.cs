﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping.App
{
    public class Product
    {
        public Product(string sku, string name, double price)
        {
            SKU = sku;
            Name = name;
            Price = price;
        }
        public string SKU { set; get; }
        public string Name { set; get; }
        public double Price { set; get; }

    }
}
