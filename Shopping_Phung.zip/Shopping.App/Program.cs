﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Shopping.App
{
    class Program
    {

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("SKUs Scanned: ");
                string input = Console.ReadLine();
                string[] arr = input.Split(',');
                Checkout co = new Checkout(Data.PRICERULES);
                for (int i = 0; i < arr.Count(); i++)
                {
                    var item = arr[i].Trim();
                    co.Scan(item);
                }
                var amount = co.Total(Data.PRODUCTS);
                Console.WriteLine("Total expected: " + String.Format("{0:C}", amount));
            }
        }
    }
}
