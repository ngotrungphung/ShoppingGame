using Shopping.App;

namespace Shopping.Test
{
    [TestClass]
    public class ShoppingCartTest
    {

        [TestMethod]
        [DataRow("atv, atv, atv, vga")]
        public void When_get_2_deals_Atv_And_Vga(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 249.00);
        }

        [TestMethod]
        [DataRow("atv, ipd, ipd, atv, ipd, ipd, ipd")]
        public void When_get_2_deals_Atv_And_discount_ipd(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 2718.95);
        }

        [TestMethod]
        [DataRow("mbp, vga, ipd")]
        public void When_get_vga_free_for_mbp_And_discount_ipd(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 1949.98);
        }

        [TestMethod]
        [DataRow("atv, atv, vga, ipd, atv, ipd, mbp, vga")]
        public void When_get_many_atv_And_mbp_less_than_vga(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 2778.9700000000003);
        }

        [TestMethod]
        [DataRow("atv, atv, ipd, ipd, mbp, vga, ipd, ipd, atv, vga, ipd, mbp, vga, ipd")]
        public void When_get_many_ipd_And_mbp_less_than_vga(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 6048.92);
        }

        [TestMethod]
        [DataRow("atv, atv,mbp, mbp, mbp,  atv,vga, ipd, vga,ipd, ipd, ipd, ipd,  vga, vga, atv")]
        public void When_get_many_ipd_atv_And_vga_less_than_mbp(string scans)
        {
            string[] arr = scans.Split(',');
            Checkout co = new Checkout(Data.PRICERULES);
            for (int i = 0; i < arr.Count(); i++)
            {
                var item = arr[i].Trim();
                co.Scan(item);
            }
            var amount = co.Total(Data.PRODUCTS);
            Assert.AreEqual(amount, 7058.42);
        }
    }
}